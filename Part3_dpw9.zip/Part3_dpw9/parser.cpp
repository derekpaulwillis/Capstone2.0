// ============================================================================
//  parser.cpp — Recursive-descent parser (Part 3: value/term/factor/primary)
// ----------------------------------------------------------------------------
//  Uses ValueNode hierarchy from ast.h and tokens from lexer.h
// ============================================================================

#include <memory>
#include <stdexcept>
#include <sstream>
#include <string>
#include <set>
#include "lexer.h"
#include "ast.h"
#include "debug.h"

using namespace std;

// -----------------------------------------------------------------------------
// One-token lookahead
// -----------------------------------------------------------------------------
static bool   havePeek = false;
static Token  peekTok  = 0;
static string peekLex;

inline const char* tname(Token t) { return tokName(t); }

// peek(): return current lookahead, lexing if needed
Token peek() {
  if (!havePeek) {
    peekTok = yylex();
    if (peekTok == 0) {
      peekTok = TOK_EOF;
      peekLex.clear();
    } else {
      peekLex = yytext ? string(yytext) : string();
    }
    dbg::line(string("peek: ") + tname(peekTok) +
              (peekLex.empty() ? "" : " [" + peekLex + "]") +
              " @ line " + to_string(yylineno));
    havePeek = true;
  }
  return peekTok;
}

// nextTok(): low-level consumer (only used *inside* expect)
Token nextTok() {
  Token t = peek();
  dbg::line(string("consume: ") + tname(t));
  havePeek = false;
  return t;
}

// expect(): consume a specific token kind or throw a parse error
Token expect(Token want, const char* msg) {
  Token got = nextTok();
  if (got != want) {
    dbg::line(string("expect FAIL: wanted ") + tname(want) +
              ", got " + tname(got));
    ostringstream oss;
    oss << "Parse error (line " << yylineno << "): expected "
        << tname(want) << " — " << msg << ", got " << tname(got)
        << " [" << (yytext ? yytext : "") << "]";
    throw runtime_error(oss.str());
  }
  return got;
}

// -----------------------------------------------------------------------------
// Forwards
// -----------------------------------------------------------------------------
unique_ptr<CompoundStmt> parseCompound();
unique_ptr<Statement>    parseStmt();
unique_ptr<Block>        parseBlock();
unique_ptr<Program>      parseProgram();

unique_ptr<AssignStmt>   parseAssign();
unique_ptr<ReadStmt>     parseRead();
unique_ptr<WriteStmt>    parseWrite();

// Prefix ++/-- statement form:  ++X;  --Y;
unique_ptr<Statement>    parsePreIncDecStmt();

// Part 3 expressions
// value   → term   { (+|-) term }
// term    → factor { (*|/|MOD|^^) factor }
// factor  → [ ++ | -- | - ] primary | primary
// primary → INTLIT | FLOATLIT | IDENT | '(' value ')'
unique_ptr<ValueNode> parseValue();
unique_ptr<ValueNode> parseTerm();
unique_ptr<ValueNode> parseFactor();
unique_ptr<ValueNode> parsePrimary();

// ============================================================================
// Compound
// ============================================================================
unique_ptr<CompoundStmt> parseCompound() {
  auto node = make_unique<CompoundStmt>();
  expect(TOK_BEGIN, "BEGIN needed to open compound statement");

  // at least one statement
  node->stmt_list.push_back(parseStmt());
  while (peek() == SEMICOLON) {
    expect(SEMICOLON, "must follow all but last stmt");
    node->stmt_list.push_back(parseStmt());
  }
  expect(END, "END must be used to end the list");
  return node;
}

// ============================================================================
// Assignment (Part 3: RHS is a full value)
//   IDENT := value
// ============================================================================
unique_ptr<AssignStmt> parseAssign() {
  expect(IDENT, "Identifier expected");
  string name = peekLex;  // lexeme of just-consumed IDENT

  if (symbolTable.find(name) == symbolTable.end())
    throw runtime_error("var not declared");

  expect(ASSIGN, "must follow identifier");
  auto rhs = parseValue();

  auto node = make_unique<AssignStmt>();
  node->id  = name;
  node->rhs = move(rhs);
  return node;
}

// ============================================================================
// Prefix ++/-- statement:  ++X;  --Y;
// Desugared to: Assign X := (UnaryOp(++/--, Var X))
// ============================================================================
unique_ptr<Statement> parsePreIncDecStmt() {
  Token op = peek();
  if (op != INCREMENT && op != DECREMENT)
    throw runtime_error("internal: expected prefix ++/--");

  // Use expect() to actually consume the operator
  expect(op, "prefix ++/-- operator");

  expect(IDENT, "identifier after prefix ++/--");
  string name = peekLex;

  if (symbolTable.find(name) == symbolTable.end())
    throw runtime_error("variable not declared");

  auto var  = make_unique<IdentNode>(name);
  auto uexp = make_unique<UnaryOp>(op, move(var));

  auto stmt = make_unique<AssignStmt>();
  stmt->id  = name;
  stmt->rhs = move(uexp);
  return stmt;
}

// ============================================================================
// READ
// ============================================================================
unique_ptr<ReadStmt> parseRead() {
  auto node = make_unique<ReadStmt>();
  expect(READ, "start a READ function");
  expect(OPENPAREN, "must follow READ");
  expect(IDENT, "must contain variable name");
  string varName = peekLex;

  if (symbolTable.find(varName) == symbolTable.end())
    throw runtime_error("Variable not declared");

  node->id = varName;
  expect(CLOSEPAREN, "must be used to end a read function");
  return node;
}

// ============================================================================
// WRITE  (IDENT or STRINGLIT like Part 2)
// ============================================================================
unique_ptr<WriteStmt> parseWrite() {
  auto node = make_unique<WriteStmt>();
  expect(WRITE, "start a WRITE function");
  expect(OPENPAREN, "must follow WRITE");

  Token w = peek();
  if (w == IDENT) {
    expect(IDENT, "Identifier to be written");
  } else if (w == STRINGLIT) {
    expect(STRINGLIT, "String to be written");
  } else {
    throw runtime_error("did not write a string or identifier");
  }

  node->type = w;
  string stripped = peekLex;
  if (w == STRINGLIT) {
    // strip surrounding single quotes
    stripped = stripped.substr(1, stripped.length() - 2);
  }
  node->content = stripped;

  expect(CLOSEPAREN, "must end a write function");
  return node;
}

// ============================================================================
// Statement dispatcher
// ============================================================================
unique_ptr<Statement> parseStmt() {
  switch (peek()) {
    case TOK_BEGIN: return parseCompound();
    case READ:      return parseRead();
    case WRITE:     return parseWrite();
    case INCREMENT: // ++X;
    case DECREMENT: // --Y;
      return parsePreIncDecStmt();
    case IDENT:     // X := value;
      return parseAssign();
    default:
      throw runtime_error("Stmt did not start correctly");
  }
}

// ============================================================================
// Block
// ============================================================================
unique_ptr<Block> parseBlock() {
  auto node = make_unique<Block>();

  if (peek() == VAR) {
    expect(VAR, "start declarations");

    // First decl (require at least one)
    expect(IDENT, "must contain one declaration");
    string varName = peekLex;
    expect(COLON, ": must follow variable name");

    if (peek() == INTEGER)      expect(INTEGER, "variable type expected");
    else if (peek() == REAL)    expect(REAL, "variable type expected");
    else                        throw runtime_error("Variable type not correct");

    string varType = peekLex;
    expect(SEMICOLON, "semicolon must end declaration lines");

    bool inserted = (varType == "INTEGER")
      ? symbolTable.insert({varName, Value{int(0)}}).second
      : symbolTable.insert({varName, Value{double(0.0)}}).second;
    if (!inserted) throw runtime_error("variable already declared");

    // Zero or more additional declarations
    while (peek() == IDENT) {
      expect(IDENT, "must contain one declaration");
      string v2 = peekLex;
      expect(COLON, ": must follow variable name");

      if (peek() == INTEGER)      expect(INTEGER, "variable type expected");
      else if (peek() == REAL)    expect(REAL, "variable type expected");
      else                        throw runtime_error("Variable type not correct");

      string t2 = peekLex;
      expect(SEMICOLON, "semicolon must end declaration lines");

      bool ok = (t2 == "INTEGER")
        ? symbolTable.insert({v2, Value{int(0)}}).second
        : symbolTable.insert({v2, Value{double(0.0)}}).second;
      if (!ok) throw runtime_error("variable already declared");
    }
  }

  if (peek() == TOK_BEGIN) {
    node->compound = parseCompound();
  } else {
    throw runtime_error("Block did not start with VAR or BEGIN");
  }

  return node;
}

// ============================================================================
// Program
// ============================================================================
unique_ptr<Program> parseProgram() {
  expect(PROGRAM, "start of program");
  expect(IDENT, "program name");
  string nameLex = peekLex;
  expect(SEMICOLON, "after program name");

  auto p = make_unique<Program>();
  p->name  = nameLex;
  p->block = parseBlock();

  expect(TOK_EOF, "at end of file (no trailing tokens after program)");
  return p;
}

// ============================================================================
// -------------------------- Part 3: Expressions ------------------------------
// Grammar (exact names from your PDF):
//   value   → term   { (PLUS | MINUS) term }
//   term    → factor { (MULTIPLY | DIVIDE | MOD | CUSTOM_OPER) factor }
//   factor  → [ INCREMENT | DECREMENT | MINUS ] primary | primary
//   primary → FLOATLIT | INTLIT | IDENT | '(' value ')'
// -----------------------------------------------------------------------------


// primary: INTLIT | FLOATLIT | IDENT | '(' value ')'
unique_ptr<ValueNode> parsePrimary() {
  Token t = peek();
  if (t == OPENPAREN) {
    expect(OPENPAREN, "open '(' for value");
    auto v = parseValue();
    expect(CLOSEPAREN, "closing ')'");
    return v;
  }
  if (t == INTLIT) {
    expect(INTLIT, "integer literal");
    return make_unique<IntLitNode>(stoi(peekLex));
  }
  if (t == FLOATLIT) {
    expect(FLOATLIT, "float literal");
    return make_unique<RealLitNode>(stod(peekLex));
  }
  if (t == IDENT) {
    expect(IDENT, "identifier");
    return make_unique<IdentNode>(peekLex);
  }

  throw runtime_error("Parse error: expected value or '(' to start expression");
}

// factor: [ ++ | -- | - ] primary | primary
unique_ptr<ValueNode> parseFactor() {
  Token t = peek();
  if (t == INCREMENT || t == DECREMENT || t == MINUS) {
    Token op = t;  // remember which unary operator we saw
    expect(t, "unary operator (++/--/-) in factor");
    auto p = parsePrimary();
    return make_unique<UnaryOp>(op, move(p));
  }
  return parsePrimary();
}

// term: factor { (* | / | MOD | ^^) factor }
unique_ptr<ValueNode> parseTerm() {
  auto node = parseFactor();
  while (true) {
    Token t = peek();
    if (t == MULTIPLY || t == DIVIDE || t == MOD || t == CUSTOM_OPER) {
      Token op = t;
      expect(t, "multiplicative operator (*, /, MOD, ^^) in term");
      auto rhs = parseFactor();
      node = make_unique<BinaryOp>(move(node), op, move(rhs));
    } else {
      break;
    }
  }
  return node;
}

// value: term { (+ | -) term }
unique_ptr<ValueNode> parseValue() {
  auto node = parseTerm();
  while (true) {
    Token t = peek();
    if (t == PLUS || t == MINUS) {
      Token op = t;
      expect(t, "additive operator (+/-) in value");
      auto rhs = parseTerm();
      node = make_unique<BinaryOp>(move(node), op, move(rhs));
    } else {
      break;
    }
  }
  return node;
}

#pragma once
#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <variant>
#include <cmath>
#include <stdexcept>
#include "lexer.h"
using namespace std;

// -----------------------------------------------------------------------------
// Helpers / shared types
// -----------------------------------------------------------------------------
inline void ast_line(ostream& os, string prefix, bool last, string label) {
  os << prefix << (last ? "└── " : "├── ") << label << "\n";
}

using Value = variant<int,double>;
inline map<string,Value> symbolTable;

inline double as_double(const Value& v) {
  return holds_alternative<int>(v) ? static_cast<double>(get<int>(v)) : get<double>(v);
}
inline int as_int_strict(const Value& v) {
  if (!holds_alternative<int>(v)) throw runtime_error("MOD requires INTEGER operands");
  return get<int>(v);
}

// -----------------------------------------------------------------------------
// ValueNode hierarchy (represents value/term/factor/primary in Part 3)
// -----------------------------------------------------------------------------
struct ValueNode {
  virtual void print_tree(ostream& os, string prefix) = 0;
  virtual Value interpret(ostream& out) = 0;
};

// --- Leaves ---
struct IntLitNode : ValueNode {
  int v;
  explicit IntLitNode(int vv) : v(vv) {}
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Int " + to_string(v));
  }
  Value interpret(ostream& out) override { (void)out; return v; }
};

struct RealLitNode : ValueNode {
  double v;
  explicit RealLitNode(double vv) : v(vv) {}
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Real " + to_string(v));
  }
  Value interpret(ostream& out) override { (void)out; return v; }
};

struct IdentNode : ValueNode {
  string name;
  explicit IdentNode(string n) : name(move(n)) {}
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Var " + name);
  }
  Value interpret(ostream& out) override {
    (void)out;
    auto it = symbolTable.find(name);
    if (it == symbolTable.end()) throw runtime_error("Identifier not declared: " + name);
    return it->second;
  }
};

// --- Unary ---
struct UnaryOp : ValueNode {
  Token op;
  unique_ptr<ValueNode> sub;
  UnaryOp(Token op_, unique_ptr<ValueNode> sub_) : op(op_), sub(move(sub_)) {}
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, false, "Unary");
    ast_line(os, prefix + "│   ", false, "op: " + string(tokName(op)));
    sub->print_tree(os, prefix + "    ");
  }
  Value interpret(ostream& out) override {
    (void)out;
    if (op == MINUS) {
      Value v = sub->interpret(out);
      if (holds_alternative<int>(v)) return -get<int>(v);
      return -get<double>(v);
    }
    if (op == INCREMENT || op == DECREMENT) {
      auto* id = dynamic_cast<IdentNode*>(sub.get());
      if (!id) throw runtime_error("++/-- must apply to an identifier");
      auto& slot = symbolTable[id->name];
      if (holds_alternative<int>(slot)) {
        int x = get<int>(slot);
        x += (op == INCREMENT ? 1 : -1);
        slot = x;
        return x;
      } else {
        double x = get<double>(slot);
        x += (op == INCREMENT ? 1.0 : -1.0);
        slot = x;
        return x;
      }
    }
    throw runtime_error("Unknown unary operator");
  }
};

// --- Binary ---
struct BinaryOp : ValueNode {
  Token op;
  unique_ptr<ValueNode> left, right;
  BinaryOp(unique_ptr<ValueNode> L, Token op_, unique_ptr<ValueNode> R)
      : op(op_), left(move(L)), right(move(R)) {}
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, false, "Binary " + string(tokName(op)));
    left->print_tree(os,  prefix + "│   ");
    right->print_tree(os, prefix + "    ");
  }
  Value interpret(ostream& out) override {
    (void)out;
    Value a = left->interpret(out);
    Value b = right->interpret(out);

    switch (op) {
      case PLUS: case MINUS: {
        if (holds_alternative<int>(a) && holds_alternative<int>(b))
          return (op == PLUS) ? get<int>(a) + get<int>(b)
                              : get<int>(a) - get<int>(b);
        double ad = as_double(a), bd = as_double(b);
        return (op == PLUS) ? ad + bd : ad - bd;
      }
      case MULTIPLY: case DIVIDE: {
        if (op == MULTIPLY && holds_alternative<int>(a) && holds_alternative<int>(b))
          return get<int>(a) * get<int>(b);
        double ad = as_double(a), bd = as_double(b);
        if (op == DIVIDE) return ad / bd;
        return ad * bd;
      }
      case MOD: {
        int ai = as_int_strict(a), bi = as_int_strict(b);
        if (bi == 0) throw runtime_error("Division by zero in MOD");
        return ai % bi;
      }
      case CUSTOM_OPER: { // ^^ exponent
        if (holds_alternative<int>(a) && holds_alternative<int>(b)) {
          int base = get<int>(a), exp = get<int>(b);
          if (exp < 0) return pow(static_cast<double>(base), static_cast<double>(exp));
          long long res = 1, bb = base;
          int e = exp;
          while (e > 0) { if (e & 1) res *= bb; bb *= bb; e >>= 1; }
          return static_cast<int>(res);
        }
        return pow(as_double(a), as_double(b));
      }
      default:
        throw runtime_error("Unknown binary operator");
    }
  }
};

// -----------------------------------------------------------------------------
// Statements
// -----------------------------------------------------------------------------
struct Statement {
  virtual void print_tree(ostream& os, string prefix) = 0;
  virtual void interpret(ostream& out) = 0;
};

struct CompoundStmt : Statement {
  vector<unique_ptr<Statement>> stmt_list;
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Compound Statement");
    for (auto& s : stmt_list) s->print_tree(os, "    " + prefix);
  }
  void interpret(ostream& out) override {
    for (auto& s : stmt_list) s->interpret(out);
  }
};

struct WriteStmt : Statement {
  Token type; string content;
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Write");
    ast_line(os, prefix + "    ", true, "content: " + content);
  }
  void interpret(ostream& out) override {
    auto it = symbolTable.find(content);
    if (it != symbolTable.end())
      visit([&](auto&& v){ out << v << "\n"; }, it->second);
    else
      out << content << "\n";
  }
};

struct ReadStmt : Statement {
  string id;
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, true, "Read " + id);
  }
  void interpret(ostream& out) override {
    (void)out;
    auto it = symbolTable.find(id);
    if (it == symbolTable.end()) throw runtime_error("Variable not declared: " + id);
    visit([&](auto& slot){ cin >> slot; }, it->second);
  }
};

struct AssignStmt : Statement {
  string id;
  unique_ptr<ValueNode> rhs;
  void print_tree(ostream& os, string prefix) override {
    ast_line(os, prefix, false, "Assign " + id + " :=");
    rhs ? rhs->print_tree(os, prefix + "    ")
        : ast_line(os, prefix + "    ", true, "(null expr)");
  }
  void interpret(ostream& out) override {
    (void)out;
    auto val = rhs->interpret(out);
    auto& slot = symbolTable[id];
    visit([&](auto& s){
      s = static_cast<decay_t<decltype(s)>>(
            holds_alternative<int>(val) ? get<int>(val) : get<double>(val));
    }, slot);
  }
};

// -----------------------------------------------------------------------------
// Block & Program
// -----------------------------------------------------------------------------
struct Block {
  unique_ptr<CompoundStmt> compound;
  void print_tree(ostream& os) {
    ast_line(os, "", true, "Block");
    if (symbolTable.empty()) {
      ast_line(os, "    ", false, "no declarations");
    } else {
      ast_line(os, "    ", false, "declarations:");
      for (auto& [name, val] : symbolTable) {
        bool isInt = holds_alternative<int>(val);
        string type = isInt ? "INTEGER" : "REAL";
        string sval = isInt ? to_string(get<int>(val)) : to_string(get<double>(val));
        ast_line(os, "    |   ", false, name + " : " + type + " = " + sval);
      }
    }
    if (compound) compound->print_tree(os, "    ");
  }
  void interpret(ostream& out) { if (compound) compound->interpret(out); }
};

struct Program {
  string name;
  unique_ptr<Block> block;
  void print_tree(ostream& os) {
    cout << "Program\n";
    ast_line(os, "", false, "name: " + name);
    if (block) block->print_tree(os);
    else { ast_line(os, "", true, "Block"); ast_line(os, "    ", true, "(empty)"); }
  }
  void interpret(ostream& out) { if (block) block->interpret(out); }
  friend ostream& operator<<(ostream& os, unique_ptr<Program>& p) {
    if (p) p->print_tree(os);
    return os;
  }
};
